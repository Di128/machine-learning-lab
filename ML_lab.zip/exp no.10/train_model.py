import os
import pickle
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

MODEL_PATH = os.path.join("models", "rbf_svm_pipeline.pkl")
DATA_PATH = os.path.join("data", "breast_cancer.csv")

def main():
    dataset = load_breast_cancer(as_frame=True)
    X, y = dataset.data, dataset.target
    df = X.copy()
    df["target"] = y
    os.makedirs("data", exist_ok=True)
    df.to_csv(DATA_PATH, index=False)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    model = Pipeline([
        ("scaler", StandardScaler()),
        ("svm", SVC(kernel="rbf", C=1.0, gamma="scale"))
    ])
    model.fit(X_train, y_train)
    predicted = model.predict(X_test)

    os.makedirs("models", exist_ok=True)
    artifact = {
        "pipeline": model,
        "feature_names": list(X.columns),
        "medians": X_train.median().to_dict(),
        "visible_features": list(X.columns[:5])
    }
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(artifact, f)

    print(f"Test accuracy: {accuracy_score(y_test, predicted):.4f}")
    print("Confusion matrix (rows=true, columns=predicted):\\n", confusion_matrix(y_test, predicted))
    print("Classification report:\\n", classification_report(
        y_test, predicted, target_names=dataset.target_names
    ))
    print("Class mapping:", dict(enumerate(dataset.target_names)))
    print(f"Saved model: {MODEL_PATH}")

if __name__ == "__main__":
    main()
