import os
import pickle
import numpy as np
import pandas as pd
from flask import Flask, render_template, request

app = Flask(__name__)
MODEL_PATH = os.path.join("models", "rbf_svm_pipeline.pkl")
artifact = None

def load_model():
    global artifact
    if os.path.exists(MODEL_PATH):
        with open(MODEL_PATH, "rb") as f:
            artifact = pickle.load(f)

load_model()

@app.route("/", methods=["GET"])
def home():
    features = artifact["visible_features"] if artifact else [
        "mean radius", "mean texture", "mean perimeter", "mean area", "mean smoothness"
    ]
    return render_template("index.html", features=features, result=None, error=None)

@app.route("/predict", methods=["POST"])
def predict():
    try:
        if artifact is None:
            raise RuntimeError("Model not found. Run `python train_model.py` first.")
        row = artifact["medians"].copy()
        for name in artifact["visible_features"]:
            value = float(request.form[name])
            if not np.isfinite(value):
                raise ValueError(f"Enter a valid number for {name}.")
            row[name] = value
        sample = pd.DataFrame([[row[name] for name in artifact["feature_names"]]],
                              columns=artifact["feature_names"])
        predicted = int(artifact["pipeline"].predict(sample)[0])
        label = "Malignant" if predicted == 0 else "Benign"
        return render_template("index.html", features=artifact["visible_features"],
                               result=label, error=None)
    except (ValueError, KeyError) as exc:
        return render_template("index.html", features=artifact["visible_features"] if artifact else [],
                               result=None, error=f"Input error: {exc}")
    except RuntimeError as exc:
        return render_template("index.html", features=[], result=None, error=str(exc))

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5001, debug=True)
