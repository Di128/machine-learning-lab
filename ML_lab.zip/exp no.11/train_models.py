import os
import json
import urllib.request
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_selection import SelectKBest, f_classif, f_regression
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    mean_absolute_error, mean_squared_error, r2_score,
    confusion_matrix, classification_report
)

warnings.filterwarnings("ignore")
DATA_DIR, MODEL_DIR, RESULT_DIR = "data", "models", "results"
DATA_PATH = os.path.join(DATA_DIR, "winequality-red.csv")
UCI_URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv"
FEATURES = [
    "fixed acidity", "volatile acidity", "citric acid", "residual sugar",
    "chlorides", "free sulfur dioxide", "total sulfur dioxide", "density",
    "pH", "sulphates", "alcohol"
]

def load_dataset():
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(DATA_PATH) or os.path.getsize(DATA_PATH) < 1000:
        print("Downloading UCI Wine Quality red wine dataset...")
        try:
            request = urllib.request.Request(UCI_URL, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(request, timeout=30) as response:
                content = response.read()
            with open(DATA_PATH, "wb") as f:
                f.write(content)
        except Exception as exc:
            raise RuntimeError(
                "Could not download the UCI dataset. Connect to the internet and retry. "
                "You can also manually download winequality-red.csv from the UCI Wine Quality "
                "dataset and place it inside the data folder."
            ) from exc
    return pd.read_csv(DATA_PATH, sep=";")

def save_eda(df):
    os.makedirs(RESULT_DIR, exist_ok=True)
    plt.figure(figsize=(7, 4))
    sns.countplot(data=df, x="quality")
    plt.title("Distribution of Wine Quality Scores")
    plt.xlabel("Quality score")
    plt.ylabel("Number of samples")
    plt.tight_layout()
    plt.savefig(os.path.join(RESULT_DIR, "quality_distribution.png"), dpi=150)
    plt.close()

    plt.figure(figsize=(11, 8))
    sns.heatmap(df.corr(numeric_only=True), cmap="coolwarm", center=0, annot=False)
    plt.title("Correlation Heatmap – Wine Quality Dataset")
    plt.tight_layout()
    plt.savefig(os.path.join(RESULT_DIR, "correlation_heatmap.png"), dpi=150)
    plt.close()

    plt.figure(figsize=(8, 4))
    df[FEATURES].std().sort_values(ascending=False).plot(kind="bar")
    plt.title("Feature Variability (Standard Deviation)")
    plt.ylabel("Standard deviation")
    plt.tight_layout()
    plt.savefig(os.path.join(RESULT_DIR, "feature_variability.png"), dpi=150)
    plt.close()

def main():
    os.makedirs(MODEL_DIR, exist_ok=True)
    os.makedirs(RESULT_DIR, exist_ok=True)
    df = load_dataset()

    print("\\n--- Initial inspection ---")
    print("Shape:", df.shape)
    print("\\nData types:\\n", df.dtypes)
    print("\\nMissing values:\\n", df.isnull().sum())
    print("Duplicate rows:", int(df.duplicated().sum()))

    # Cleaning: remove duplicate records; median-impute any missing numeric values.
    df = df.drop_duplicates().copy()
    df[FEATURES + ["quality"]] = df[FEATURES + ["quality"]].apply(
        lambda col: col.fillna(col.median())
    )
    df.to_csv(os.path.join(DATA_DIR, "winequality_red_cleaned.csv"), index=False)
    save_eda(df)

    X = df[FEATURES].copy()
    y_reg = df["quality"].astype(float)
    y_clf = (df["quality"] >= 6).astype(int)

    # Classification: one shared stratified split for both algorithms.
    Xc_train, Xc_test, yc_train, yc_test = train_test_split(
        X, y_clf, test_size=0.20, random_state=42, stratify=y_clf
    )
    # Regression: one shared split for both algorithms.
    Xr_train, Xr_test, yr_train, yr_test = train_test_split(
        X, y_reg, test_size=0.20, random_state=42
    )

    # Feature selection is fitted only on each training partition to avoid leakage.
    # The same selected-feature procedure is used for both algorithms in each task.
    classifiers = {
        "Decision Tree": Pipeline([
            ("feature_selection", SelectKBest(score_func=f_classif, k=8)),
            ("model", DecisionTreeClassifier(
                max_depth=6, min_samples_split=4, random_state=42, class_weight="balanced"
            ))
        ]),
        "Random Forest": Pipeline([
            ("feature_selection", SelectKBest(score_func=f_classif, k=8)),
            ("model", RandomForestClassifier(
                n_estimators=200, max_depth=None, min_samples_split=2,
                random_state=42, class_weight="balanced", n_jobs=-1
            ))
        ])
    }
    regressors = {
        "Decision Tree": Pipeline([
            ("feature_selection", SelectKBest(score_func=f_regression, k=8)),
            ("model", DecisionTreeRegressor(
                max_depth=6, min_samples_split=4, random_state=42
            ))
        ]),
        "Random Forest": Pipeline([
            ("feature_selection", SelectKBest(score_func=f_regression, k=8)),
            ("model", RandomForestRegressor(
                n_estimators=200, max_depth=None, min_samples_split=2,
                random_state=42, n_jobs=-1
            ))
        ])
    }

    clf_rows, reg_rows = [], []
    for name, model in classifiers.items():
        model.fit(Xc_train, yc_train)
        pred = model.predict(Xc_test)
        clf_rows.append({
            "Algorithm": name,
            "Accuracy": accuracy_score(yc_test, pred),
            "Precision": precision_score(yc_test, pred, zero_division=0),
            "Recall": recall_score(yc_test, pred, zero_division=0),
            "F1 Score": f1_score(yc_test, pred, zero_division=0)
        })
        import pickle
        with open(os.path.join(MODEL_DIR, name.lower().replace(" ", "_") + "_classifier.pkl"), "wb") as f:
            pickle.dump(model, f)
        if name == "Random Forest":
            cm = confusion_matrix(yc_test, pred)
            plt.figure(figsize=(5, 4))
            sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                        xticklabels=["Not good", "Good"], yticklabels=["Not good", "Good"])
            plt.title("Random Forest Classification – Confusion Matrix")
            plt.xlabel("Predicted")
            plt.ylabel("Actual")
            plt.tight_layout()
            plt.savefig(os.path.join(RESULT_DIR, "classification_confusion_matrix.png"), dpi=150)
            plt.close()
            with open(os.path.join(RESULT_DIR, "classification_report.txt"), "w", encoding="utf-8") as f:
                f.write(classification_report(yc_test, pred, target_names=["Not good", "Good"]))

    for name, model in regressors.items():
        model.fit(Xr_train, yr_train)
        pred = model.predict(Xr_test)
        mse = mean_squared_error(yr_test, pred)
        reg_rows.append({
            "Algorithm": name,
            "MAE": mean_absolute_error(yr_test, pred),
            "MSE": mse,
            "RMSE": float(np.sqrt(mse)),
            "R2 Score": r2_score(yr_test, pred)
        })
        import pickle
        with open(os.path.join(MODEL_DIR, name.lower().replace(" ", "_") + "_regressor.pkl"), "wb") as f:
            pickle.dump(model, f)
        if name == "Random Forest":
            plt.figure(figsize=(6, 5))
            plt.scatter(yr_test, pred, alpha=0.65)
            low, high = min(yr_test.min(), pred.min()), max(yr_test.max(), pred.max())
            plt.plot([low, high], [low, high], "r--")
            plt.xlabel("Actual quality")
            plt.ylabel("Predicted quality")
            plt.title("Random Forest Regression – Actual vs Predicted")
            plt.tight_layout()
            plt.savefig(os.path.join(RESULT_DIR, "regression_actual_vs_predicted.png"), dpi=150)
            plt.close()

    clf_results = pd.DataFrame(clf_rows)
    reg_results = pd.DataFrame(reg_rows)
    clf_results.to_csv(os.path.join(RESULT_DIR, "classification_comparison.csv"), index=False)
    reg_results.to_csv(os.path.join(RESULT_DIR, "regression_comparison.csv"), index=False)
    summary = {"classification": clf_rows, "regression": reg_rows,
               "dataset_rows_after_cleaning": int(len(df)),
               "feature_names": FEATURES,
               "classification_target": "good if quality >= 6, otherwise not good"}
    with open(os.path.join(RESULT_DIR, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    # Comparison visualizations
    clf_results.set_index("Algorithm")[["Accuracy", "Precision", "Recall", "F1 Score"]].plot(
        kind="bar", figsize=(9, 5), ylim=(0, 1), rot=0
    )
    plt.title("Classification Performance Comparison")
    plt.ylabel("Score")
    plt.tight_layout()
    plt.savefig(os.path.join(RESULT_DIR, "classification_comparison.png"), dpi=150)
    plt.close()

    reg_results.set_index("Algorithm")[["MAE", "RMSE"]].plot(kind="bar", figsize=(8, 5), rot=0)
    plt.title("Regression Error Comparison (lower is better)")
    plt.ylabel("Error")
    plt.tight_layout()
    plt.savefig(os.path.join(RESULT_DIR, "regression_comparison.png"), dpi=150)
    plt.close()

    print("\\n--- Classification comparison ---\\n", clf_results.to_string(index=False))
    print("\\n--- Regression comparison ---\\n", reg_results.to_string(index=False))
    print("\\nSaved trained models, metrics and visualizations in models/ and results/.")

if __name__ == "__main__":
    main()
