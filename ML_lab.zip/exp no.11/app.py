import os
import pickle
import numpy as np
from flask import Flask, render_template, request

app = Flask(__name__)
FEATURES = [
    "fixed acidity", "volatile acidity", "citric acid", "residual sugar",
    "chlorides", "free sulfur dioxide", "total sulfur dioxide", "density",
    "pH", "sulphates", "alcohol"
]
MODEL_DIR = "models"

def load_pickle(filename):
    path = os.path.join(MODEL_DIR, filename)
    if os.path.exists(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    return None

@app.route("/")
def home():
    return render_template("index.html", features=FEATURES, prediction=None, error=None)

@app.route("/predict", methods=["POST"])
def predict():
    task = request.form.get("task", "classification")
    algorithm = request.form.get("algorithm", "Random Forest")
    suffix = "classifier" if task == "classification" else "regressor"
    filename = algorithm.lower().replace(" ", "_") + "_" + suffix + ".pkl"
    model = load_pickle(filename)
    if model is None:
        return render_template("index.html", features=FEATURES, prediction=None,
            error="Trained model not found. Run python train_models.py first.")
    try:
        values = [float(request.form[f"f{i}"]) for i in range(len(FEATURES))]
        if not np.all(np.isfinite(values)):
            raise ValueError("All feature values must be valid finite numbers.")
        result = float(model.predict([values])[0])
        if task == "classification":
            label = "Good quality (quality score 6 or above)" if int(result) == 1 else "Not good quality (quality score below 6)"
            prediction = {"title": "Classification result", "value": label,
                          "detail": f"Algorithm: {algorithm}"}
        else:
            prediction = {"title": "Predicted quality score", "value": f"{result:.2f} / 10",
                          "detail": f"Algorithm: {algorithm}"}
        return render_template("index.html", features=FEATURES, prediction=prediction, error=None)
    except (ValueError, KeyError) as exc:
        return render_template("index.html", features=FEATURES, prediction=None, error=f"Input error: {exc}")

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5002, debug=True)
