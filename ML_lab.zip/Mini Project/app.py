
from flask import Flask, render_template, request, redirect, url_for, flash
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC, LinearSVC
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             confusion_matrix, classification_report, mean_absolute_error,
                             mean_squared_error, r2_score)
from sklearn.impute import SimpleImputer
from sklearn.datasets import load_diabetes, load_breast_cancer, load_wine
import joblib, os, urllib.request

app = Flask(__name__)
app.secret_key = "ml-lab-dashboard-local"
ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
PLOTS = ROOT / "static" / "plots"
PLOTS.mkdir(parents=True, exist_ok=True)

EXPERIMENTS = {
 "2": {"title":"Simple Linear Regression", "kind":"regression", "dataset":"diabetes.csv", "target":"target",
       "features":["bmi"], "description":"Predict a continuous diabetes disease-progression measure using one input feature (BMI)."},
 "3": {"title":"Multiple Linear Regression", "kind":"regression", "dataset":"diabetes.csv", "target":"target",
       "features":["age","sex","bmi","bp","s1","s2","s3","s4","s5","s6"],
       "description":"Predict the diabetes progression measure using multiple independent variables."},
 "4": {"title":"Logistic Regression – Binary Classification", "kind":"classification", "dataset":"placement.csv", "target":"placement",
       "features":["cgpa","iq"], "description":"Predict placement outcome (0 = not placed, 1 = placed)."},
 "5": {"title":"Logistic Regression – Multiclass Classification", "kind":"classification", "dataset":"wine_multiclass.csv", "target":"target",
       "features":["alcohol","malic_acid","ash","alcalinity_of_ash","magnesium","total_phenols","flavanoids","nonflavanoid_phenols","proanthocyanins","color_intensity","hue","od280/od315_of_diluted_wines","proline"],
       "description":"Classify wine samples into one of three classes using chemical measurements."},
 "6": {"title":"Decision Tree Classifier", "kind":"classification", "dataset":"heart_demo_generated.csv", "target":"target",
       "features":["age","sex","chest_pain","resting_bp","cholesterol","max_heart_rate","oldpeak","vessels"],
       "description":"Decision Tree classification demo. The bundled file is a generated practice dataset, not the linked clinical Heart-UCI dataset."},
 "7": {"title":"K-Nearest Neighbors (KNN) Classifier", "kind":"classification", "dataset":"breast_cancer.csv", "target":"target",
       "features":["mean radius","mean texture","mean perimeter","mean area","mean smoothness","mean compactness"],
       "description":"Classify breast-cancer samples using the bundled scikit-learn Wisconsin diagnostic dataset."},
 "8": {"title":"Naive Bayes Classifier", "kind":"classification", "dataset":"wine_multiclass.csv", "target":"target",
       "features":["alcohol","malic_acid","ash","alcalinity_of_ash","magnesium","total_phenols","flavanoids","nonflavanoid_phenols","proanthocyanins","color_intensity","hue","od280/od315_of_diluted_wines","proline"],
       "description":"Classify the three wine classes using Gaussian Naive Bayes."},
 "9": {"title":"Linear SVM – Banknote Authentication", "kind":"classification", "dataset":"banknote_authentication.csv", "target":"class",
       "features":["variance","skewness","curtosis","entropy"],
       "description":"Linear SVM on the UCI Banknote Authentication dataset. Download is attempted when training if the CSV is not bundled."},
 "10": {"title":"Non-Linear SVM – Breast Cancer", "kind":"classification", "dataset":"breast_cancer.csv", "target":"target",
       "features":["mean radius","mean texture","mean perimeter","mean area","mean smoothness","mean compactness"],
       "description":"RBF-kernel SVM on the bundled Wisconsin breast-cancer dataset."},
 "11": {"title":"Random Forest – Wine Quality", "kind":"both", "dataset":"winequality-red.csv", "target":"quality",
       "features":["fixed acidity","volatile acidity","citric acid","residual sugar","chlorides","free sulfur dioxide","total sulfur dioxide","density","pH","sulphates","alcohol"],
       "description":"Random Forest classification and regression with Decision Tree comparison on UCI Red Wine Quality. Download is attempted if the CSV is not bundled."}
}

def ensure_remote_dataset(exp_id):
    if exp_id == "9":
        path = DATA / "banknote_authentication.csv"
        if not path.exists():
            url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00267/data_banknote_authentication.txt"
            try:
                df = pd.read_csv(url, header=None, names=["variance","skewness","curtosis","entropy","class"])
                df.to_csv(path, index=False)
            except Exception:
                raise RuntimeError("Banknote dataset is not bundled. Connect to the internet and retry, or place the UCI CSV at data/banknote_authentication.csv.")
    if exp_id == "11":
        path = DATA / "winequality-red.csv"
        if not path.exists():
            url = "https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv"
            try:
                df = pd.read_csv(url, sep=";")
                df.to_csv(path, index=False)
            except Exception:
                raise RuntimeError("UCI Red Wine Quality dataset is not bundled. Connect to the internet and retry, or place winequality-red.csv in data/.")

def get_data(exp_id):
    ensure_remote_dataset(exp_id)
    spec = EXPERIMENTS[exp_id]
    df = pd.read_csv(DATA / spec["dataset"])
    if exp_id == "11":
        df["quality_class"] = (df["quality"] >= 6).astype(int)
    return df

def run_experiment(exp_id, form):
    spec = EXPERIMENTS[exp_id]
    df = get_data(exp_id).dropna()
    kind = form.get("task", "classification" if spec["kind"] != "regression" else "regression")
    if exp_id == "11":
        target = "quality" if kind == "regression" else "quality_class"
        features = spec["features"]
    else:
        target, features = spec["target"], spec["features"]
        kind = spec["kind"]
    X, y = df[features], df[target]
    test_size = float(form.get("test_size", "0.2"))
    random_state = int(form.get("random_state", "42"))
    stratify = y if kind == "classification" and y.nunique() < 20 else None
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size,
                                                        random_state=random_state, stratify=stratify)
    model_name = form.get("model", "default")
    if exp_id in ["2","3"]:
        estimator = LinearRegression()
        pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("model", estimator)])
    elif exp_id in ["4","5"]:
        estimator = LogisticRegression(max_iter=2000, C=float(form.get("C","1.0")))
        pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler()), ("model", estimator)])
    elif exp_id == "6":
        estimator = DecisionTreeClassifier(max_depth=int(form.get("max_depth") or 5), random_state=random_state)
        pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("model", estimator)])
    elif exp_id == "7":
        estimator = KNeighborsClassifier(n_neighbors=int(form.get("neighbors") or 5))
        pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler()), ("model", estimator)])
    elif exp_id == "8":
        estimator = GaussianNB()
        pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("model", estimator)])
    elif exp_id == "9":
        estimator = LinearSVC(C=float(form.get("C","1.0")), max_iter=10000, random_state=random_state)
        pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler()), ("model", estimator)])
    elif exp_id == "10":
        estimator = SVC(kernel="rbf", C=float(form.get("C","1.0")), gamma=form.get("gamma","scale"))
        pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler()), ("model", estimator)])
    elif exp_id == "11":
        if kind == "regression":
            estimator = RandomForestRegressor(n_estimators=int(form.get("trees") or 150), random_state=random_state)
            compare = __import__("sklearn.tree", fromlist=["DecisionTreeRegressor"]).DecisionTreeRegressor(random_state=random_state)
        else:
            estimator = RandomForestClassifier(n_estimators=int(form.get("trees") or 150), random_state=random_state)
            compare = DecisionTreeClassifier(random_state=random_state)
        pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("model", estimator)])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    joblib.dump(pipe, ROOT / "saved_models" / f"experiment_{exp_id}_{kind}.joblib") if (ROOT/"saved_models").exists() else None

    metrics = {}
    figpath = PLOTS / f"exp_{exp_id}_{kind}.png"
    plt.figure(figsize=(7,4.5))
    if kind == "regression":
        mse = mean_squared_error(y_test, pred)
        metrics = {"MAE": round(mean_absolute_error(y_test,pred),4), "MSE": round(mse,4),
                   "RMSE": round(float(np.sqrt(mse)),4), "R²": round(r2_score(y_test,pred),4)}
        plt.scatter(y_test, pred, alpha=.65)
        lo, hi = float(min(y_test.min(), pred.min())), float(max(y_test.max(), pred.max()))
        plt.plot([lo,hi],[lo,hi], linestyle="--")
        plt.xlabel("Actual"); plt.ylabel("Predicted"); plt.title("Actual vs Predicted")
    else:
        avg = "weighted" if y.nunique() > 2 else "binary"
        metrics = {"Accuracy": round(accuracy_score(y_test,pred),4),
                   "Precision": round(precision_score(y_test,pred,average=avg,zero_division=0),4),
                   "Recall": round(recall_score(y_test,pred,average=avg,zero_division=0),4),
                   "F1-score": round(f1_score(y_test,pred,average=avg,zero_division=0),4)}
        cm = confusion_matrix(y_test,pred)
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False)
        plt.xlabel("Predicted"); plt.ylabel("Actual"); plt.title("Confusion Matrix")
    plt.tight_layout(); plt.savefig(figpath, dpi=140); plt.close()

    comparison = None
    if exp_id == "11":
        compare_pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("model", compare)])
        compare_pipe.fit(X_train,y_train)
        cp = compare_pipe.predict(X_test)
        if kind == "regression":
            comparison = {"Decision Tree R²": round(r2_score(y_test,cp),4),
                          "Random Forest R²": metrics["R²"],
                          "Decision Tree MAE": round(mean_absolute_error(y_test,cp),4),
                          "Random Forest MAE": metrics["MAE"]}
        else:
            comparison = {"Decision Tree Accuracy": round(accuracy_score(y_test,cp),4),
                          "Random Forest Accuracy": metrics["Accuracy"],
                          "Decision Tree F1": round(f1_score(y_test,cp,average="weighted",zero_division=0),4),
                          "Random Forest F1": metrics["F1-score"]}
    preview = pd.DataFrame({"Actual": y_test.iloc[:10].values, "Predicted": pred[:10]})
    return {"metrics":metrics, "plot":f"plots/{figpath.name}", "preview":preview.to_html(index=False, classes="table"),
            "comparison":comparison, "rows":len(df), "train_rows":len(X_train), "test_rows":len(X_test),
            "dataset":spec["dataset"], "task":kind}

@app.route("/", methods=["GET","POST"])
def index():
    result = None
    selected = request.form.get("experiment", "2")
    if request.method == "POST":
        try:
            result = run_experiment(selected, request.form)
        except Exception as e:
            flash(str(e), "error")
    return render_template("index.html", experiments=EXPERIMENTS, selected=selected, result=result)

@app.route("/about")
def about():
    return render_template("about.html", experiments=EXPERIMENTS)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
