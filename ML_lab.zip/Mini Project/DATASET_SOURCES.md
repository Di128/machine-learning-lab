DATASET SOURCES

Bundled:
- Diabetes: scikit-learn load_diabetes dataset (https://scikit-learn.org/stable/datasets/toy_dataset.html#diabetes-dataset)
- Breast Cancer: scikit-learn Wisconsin Diagnostic Breast Cancer dataset (https://scikit-learn.org/stable/datasets/toy_dataset.html#breast-cancer-dataset)
- Wine multiclass: scikit-learn Wine dataset (https://scikit-learn.org/stable/datasets/toy_dataset.html#wine-recognition-dataset)
- Placement: Placement_Y_N.csv supplied in this conversation's project files.

Fetched on first run (internet required):
- UCI Banknote Authentication: https://archive.ics.uci.edu/dataset/267/banknote+authentication
- UCI Red Wine Quality: https://archive.ics.uci.edu/dataset/ red-wine-quality (CSV endpoint in app.py)

Experiment 06:
- Classroom source link shown in screenshot: https://raw.githubusercontent.com/sharmaroshan/Heart-UCI-Dataset/master/heart.csv
- This original file could not be bundled in this environment. The included heart_demo_generated.csv is generated synthetic practice data, and must not be described as the original Heart-UCI dataset.
