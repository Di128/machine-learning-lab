
# Integrated Machine Learning Algorithm Dashboard (Experiments 02–11)

A single Flask web application that brings together the ML laboratory experiments visible in the supplied screenshots. Experiment 01 is intentionally excluded as requested.

## Included experiments

| No. | Algorithm | Dataset |
|---|---|---|
| 02 | Simple Linear Regression | Diabetes progression dataset (BMI as one feature) |
| 03 | Multiple Linear Regression | Diabetes progression dataset (10 features) |
| 04 | Logistic Regression – Binary | Placement_Y_N.csv (CGPA, IQ, placement) |
| 05 | Logistic Regression – Multiclass | Scikit-learn Wine dataset (3 classes) |
| 06 | Decision Tree Classifier | Generated practice classification CSV (see note below) |
| 07 | KNN Classifier | Wisconsin Breast Cancer dataset |
| 08 | Gaussian Naive Bayes | Scikit-learn Wine dataset |
| 09 | Linear SVM | UCI Banknote Authentication (downloaded on first run) |
| 10 | Non-linear SVM (RBF) | Wisconsin Breast Cancer dataset |
| 11 | Random Forest | UCI Red Wine Quality (classification + regression), compared with Decision Tree |

A Standardization and Normalization note is included in the project scope as a preprocessing topic, but it is not numbered as an experiment in the screenshots.

## Important dataset transparency

- `diabetes.csv`, `breast_cancer.csv`, `wine_multiclass.csv`, and `placement.csv` are included in `data/`.
- `heart_demo_generated.csv` is a generated practice dataset so Experiment 06 can run offline. It is NOT the original Heart-UCI dataset linked in the classroom post and is NOT clinical data. If your instructor expects the original dataset, download the `heart.csv` file from the classroom link and replace the generated file after adapting the target/feature column names in `EXPERIMENTS` in `app.py`.
- UCI Banknote Authentication and UCI Red Wine Quality are fetched automatically the first time you run Experiments 09 and 11. Internet is required for those first runs. Their original source URLs are listed in `DATASET_SOURCES.md`.
- The dashboard never fabricates model scores; metrics are calculated when you run each experiment.

## Setup (Windows)

1. Extract the ZIP.
2. Open Command Prompt in the extracted `Integrated_ML_Dashboard` folder.
3. Create and activate a virtual environment:

```bat
python -m venv venv
venv\Scripts\activate
```

4. Install packages:

```bat
pip install -r requirements.txt
```

5. Start the app:

```bat
python app.py
```

6. Open this address in your browser:

`http://127.0.0.1:5000`

## Setup (macOS/Linux)

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Dashboard features

- Experiment selector for Experiments 02–11.
- Adjustable train/test split and random state.
- Algorithm parameters such as Logistic/SVM C, KNN neighbors, Decision Tree depth and Random Forest tree count.
- Evaluation metrics:
  - Classification: accuracy, precision, recall, F1-score and confusion matrix.
  - Regression: MAE, MSE, RMSE, R² and actual-vs-predicted scatter plot.
- Experiment 11: Decision Tree vs Random Forest comparison.
- First 10 actual and predicted test values.
- Locally generated plots; no chart CDN is required.

## Academic note

This is a consolidated demonstration project. For submission, verify dataset choice, feature names, preprocessing steps and results with your instructor's practical notebooks. Include screenshots of your own program runs and write conclusions from the metrics produced on your computer.
