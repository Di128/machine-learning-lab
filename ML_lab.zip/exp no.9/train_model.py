import os
import pickle
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

DATA_PATH = os.path.join("data", "banknote_authentication.csv")
MODEL_DIR = "models"
MODEL_PATH = os.path.join(MODEL_DIR, "linear_svm_pipeline.pkl")

def main():
    if not os.path.exists(DATA_PATH) or os.path.getsize(DATA_PATH) < 100:
        import urllib.request
        url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00267/data_banknote_authentication.txt"
        print("Downloading the UCI Banknote Authentication dataset...")
        os.makedirs("data", exist_ok=True)
        try:
            urllib.request.urlretrieve(url, DATA_PATH + ".txt")
            raw = pd.read_csv(DATA_PATH + ".txt", header=None)
            raw.columns = ["variance", "skewness", "curtosis", "entropy", "class"]
            raw.to_csv(DATA_PATH, index=False)
            os.remove(DATA_PATH + ".txt")
        except Exception as exc:
            raise RuntimeError(
                "Dataset download failed. Connect to the internet and run again, or "
                "download the UCI data_banknote_authentication.txt file and save it as "
                "data/banknote_authentication.csv with columns "
                "variance,skewness,curtosis,entropy,class."
            ) from exc
    df = pd.read_csv(DATA_PATH)
    expected = ["variance", "skewness", "curtosis", "entropy", "class"]
    if list(df.columns) != expected:
        raise ValueError(f"Expected columns {expected}, found {list(df.columns)}")
    X = df[expected[:-1]]
    y = df["class"].astype(int)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    model = Pipeline([
        ("scaler", StandardScaler()),
        ("svm", SVC(kernel="linear", C=1.0))
    ])
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    os.makedirs(MODEL_DIR, exist_ok=True)
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)
    print(f"Test accuracy: {accuracy_score(y_test, pred):.4f}")
    print("Confusion matrix:\\n", confusion_matrix(y_test, pred))
    print("Classification report:\\n", classification_report(y_test, pred))
    print(f"Saved model to {MODEL_PATH}")

if __name__ == "__main__":
    main()
