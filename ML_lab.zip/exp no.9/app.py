import os
import pickle
import numpy as np
from flask import Flask, render_template, request

app = Flask(__name__)
MODEL_PATH = os.path.join("models", "linear_svm_pipeline.pkl")
model = None

def load_model():
    global model
    if os.path.exists(MODEL_PATH):
        with open(MODEL_PATH, "rb") as f:
            model = pickle.load(f)

load_model()

@app.route("/", methods=["GET"])
def home():
    return render_template("index.html", result=None, error=None)

@app.route("/predict", methods=["POST"])
def predict():
    try:
        values = [float(request.form[name]) for name in
                  ["variance", "skewness", "curtosis", "entropy"]]
        if not np.all(np.isfinite(values)):
            raise ValueError("Please enter valid finite numbers.")
        if model is None:
            raise RuntimeError("Model not found. Run `python train_model.py` first.")
        prediction = int(model.predict(np.array(values).reshape(1, -1))[0])
        result = ("Counterfeit banknote detected" if prediction == 1
                  else "Genuine banknote detected")
        return render_template("index.html", result=result, prediction=prediction, error=None)
    except (ValueError, KeyError) as exc:
        return render_template("index.html", result=None, error=f"Input error: {exc}")
    except RuntimeError as exc:
        return render_template("index.html", result=None, error=str(exc))

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
